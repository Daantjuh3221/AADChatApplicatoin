﻿namespace MessageService.Models
{
    public class Settings
    {
        public string ConnectionString;
        public string Database;
    }
}
