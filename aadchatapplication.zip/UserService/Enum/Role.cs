﻿using System;
namespace UserService.Enum
{
    public enum Role : byte
    {
        Teacher = 1,
        Admin = 0
    }
}
